import "./globals.css";
import AppProvider from "../components/AppProvider";
import Header from "../components/Header";
import A11yDialog from "../components/A11yDialog";
import Footer from "../components/Footer";
export const metadata = { title: "EARTHSONIC — DATA BEAT", description: "Hear the changes of our planet." };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en" suppressHydrationWarning><body><AppProvider><Header /><main id="main" tabIndex={-1}>{children}</main><Footer /><A11yDialog /></AppProvider></body></html>);
}
