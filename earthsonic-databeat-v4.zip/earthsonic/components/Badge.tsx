"use client";
import { useApp } from "./AppProvider";
import type { Status } from "../lib/eic/catalog";
export default function Badge({ st }: { st: Status }) {
  const { d } = useApp();
  return <span className={`badge${st === "available" ? " ok" : ""}`}>{st === "available" ? "✔ " : st === "validation" ? "◐ " : "○ "}{st === "available" ? d.stAvailable : st === "validation" ? d.stValidating : d.stDev}</span>;
}
