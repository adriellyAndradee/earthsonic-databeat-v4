"use client";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import type { Row } from "../lib/gistemp";
import { climateFreq } from "../lib/audio/mapping";
import { indexFor } from "../lib/data/select";
import { useApp, getJson, type Fail } from "./AppProvider";
import { usePlayback } from "./usePlayback";
import SpiralChart from "./SpiralChart";
import LineChart from "./LineChart";
import ErrBox from "./ErrBox";
import Det from "./Det";

type Meta = { id: number; page: string; title: string | null; description: string | null; credits: string | null; video: string | null; image: string | null };
const strip = (s: string | null) => (s ?? "").replace(/<[^>]+>/g, "");

export default function ClimateExperience() {
  const { lang, d, prefs, data, dataErr, loadData } = useApp();
  const [svsId, setSvsId] = useState(5057), [meta, setMeta] = useState<Meta | null>(null), [metaErr, setMetaErr] = useState<Fail | null>(null);
  const [y1, setY1] = useState(0), [y2, setY2] = useState(0), [live, setLive] = useState(""), [tr, setTr] = useState<string[]>([]), [vspeed, setVspeed] = useState(0.5);
  const video = useRef<HTMLVideoElement>(null);
  const nf = (v: number) => v.toLocaleString(lang, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const mname = (m: number) => new Date(2000, m - 1, 1).toLocaleString(lang, { month: "long" });
  const loadMeta = (id: number) => { setMetaErr(null); setMeta(null); getJson<Meta>(`/api/nasa/climate-spiral?id=${id}`).then(setMeta).catch(setMetaErr); };
  useEffect(() => { loadMeta(svsId); }, [svsId]);
  useEffect(() => { if (video.current) video.current.playbackRate = vspeed; }, [vspeed, meta]);

  const all = useMemo(() => (data ? data.rows.filter((r) => svsId !== 5057 || r.year <= 2022) : []), [data, svsId]);
  useEffect(() => { if (all.length) { setY1(all[0].year); setY2(all[all.length - 1].year); } }, [all]);
  const sel = useMemo(() => all.filter((r) => r.year >= y1 && r.year <= y2), [all, y1, y2]);
  const evt = (r: Row) => d.event(mname(r.month), r.year, nf(r.anomaly), (climateFreq(r.anomaly) ?? 0).toFixed(1), r.anomaly > 0 ? d.above : r.anomaly < 0 ? d.below : d.ref);

  const pb = usePlayback<Row>(sel, {
    note: (r, sp, e) => { const f = climateFreq(r.anomaly); if (f !== null) e.note(f, 0.135 / sp); },
    step: (r) => { setTr((t) => [...t.slice(-199), evt(r)]); if (prefs.verbose || r.month === 1) setLive(d.yearAnn(r.year, mname(r.month), nf(r.anomaly))); },
    end: () => setLive(d.ended),
  });
  useEffect(() => { setTr([]); }, [sel]);
  const cur = sel[Math.min(pb.idx, sel.length - 1)], freq = cur ? climateFreq(cur.anomaly) : null;
  const fr = sel.map((r) => climateFreq(r.anomaly)).filter((v): v is number => v !== null), fmin = Math.min(...fr), fmax = Math.max(...fr);
  const pos = freq === null ? 0.5 : (freq - fmin) / (fmax - fmin || 1);
  const mn = sel.length ? Math.min(...sel.map((r) => r.anomaly)) : 0, mx = sel.length ? Math.max(...sel.map((r) => r.anomaly)) : 1, avg = sel.length ? sel.reduce((s, r) => s + r.anomaly, 0) / sel.length : 0;
  const desc = sel.length ? d.chartDesc(sel[0].year, sel[sel.length - 1].year, nf(mn), nf(mx), nf(avg)) : "";
  const years = useMemo(() => [...new Set(sel.map((r) => r.year))], [sel]);
  const goTo = (year: number, month: number) => {
    const k = indexFor(sel, year, month); if (k < 0) { setLive(d.noRecord); return; } pb.seek(k); const r = sel[k];
    setLive(d.selected(mname(r.month), r.year, nf(r.anomaly), (climateFreq(r.anomaly) ?? 0).toFixed(1)));
  };

  return (
    <article>
      <Link className="back" href="/experiences">← {d.back}</Link>
      <h1>{d.expTitles.climate}</h1><p className="lead">{d.exWhat}</p><p>{d.climIntro}</p>

      <section className="card" aria-labelledby="c1"><h2 id="c1">{d.s1}</h2>
        <label>{d.variant}<select value={svsId} onChange={(e) => setSvsId(+e.target.value)}><option value={5057}>SVS 5057 (1880–2022)</option><option value={5190}>SVS 5190</option></select></label>
        <p>{svsId === 5057 ? d.clipped : d.ver5190}</p>
        {!meta && !metaErr && <p role="status">{d.loading}</p>}
        {metaErr && <ErrBox d={d} f={metaErr} msg={d.failSvs} retry={() => loadMeta(svsId)} />}
        {meta && <>
          {meta.video ? <><video ref={video} controls preload="none" poster={meta.image ?? undefined} src={meta.video} style={{ maxHeight: 360 }} aria-label={meta.title ?? d.expTitles.climate} onLoadedMetadata={() => { if (video.current) video.current.playbackRate = vspeed; }} />
            <label>{d.videoSpeed}<select value={vspeed} onChange={(e) => setVspeed(+e.target.value)}>{[0.5, 0.75, 1, 1.5, 2].map((s) => <option key={s} value={s}>{s}x</option>)}</select></label></>
            : meta.image ? <img src={meta.image} alt={meta.title ?? d.expTitles.climate} style={{ maxHeight: 360 }} /> : <p>{d.videoMissing}</p>}
          <p><strong>{meta.title}</strong> · <a href={meta.page} target="_blank" rel="noopener">NASA SVS {meta.id}</a></p>
          <Det summary={d.readMore}><p>{strip(meta.description)}</p>{meta.credits && <p>{strip(meta.credits)}</p>}</Det></>}
      </section>

      <section className="card" aria-labelledby="c2"><h2 id="c2">{d.tData}</h2><p>{d.anomalyNote}</p><p>{d.dataSplit}</p>
        {data && <p className="mut">{data.dataset} · {data.units} · {data.baseline} · {data.firstYear}–{data.lastYear}</p>}
        <Link className="btn" href="/data">{d.openData}</Link></section>

      <section className="card" aria-labelledby="c3"><h2 id="c3">{d.s2}</h2>
        {!data && !dataErr && <p role="status">{d.loading}</p>}
        {dataErr && <ErrBox d={d} f={dataErr} msg={d.failData} retry={() => loadData()} />}
        {data && sel.length > 0 && <div className="row">
          <label>{d.startYear}<input type="number" value={y1} min={all[0].year} max={y2} onChange={(e) => setY1(Math.min(Math.max(+e.target.value || all[0].year, all[0].year), y2))} /></label>
          <label>{d.endYear}<input type="number" value={y2} min={y1} max={all[all.length - 1].year} onChange={(e) => setY2(Math.max(Math.min(+e.target.value || y2, all[all.length - 1].year), y1))} /></label></div>}
      </section>

      {data && sel.length > 0 && cur && <section className="card" aria-labelledby="c4"><h2 id="c4">{d.s3}</h2>
        <div className="row">
          {pb.playing ? <button className="pri" onClick={() => { pb.pause(); setLive(`${d.paused}: ${mname(cur.month)} ${cur.year}, ${nf(cur.anomaly)} °C.`); }}>⏸ {d.pause}</button> : <button className="pri" onClick={() => pb.play()}>▶ {pb.paused() ? d.resume : d.play}</button>}
          <button onClick={() => { pb.stop(); setTr([]); }}>⏹ {d.stop}</button><button onClick={() => { setTr([]); pb.restart(); }}>⟲ {d.restart}</button>
          <label>{d.sonSpeed}<select value={pb.speed} onChange={(e) => pb.setSpeed(+e.target.value)}>{[0.5, 0.75, 1, 1.5, 2].map((s) => <option key={s} value={s}>{s}x</option>)}</select></label>
          <label>{d.volume}<input type="range" min={0} max={100} value={pb.vol} onChange={(e) => pb.setVol(+e.target.value)} /></label></div>
        <p className="mut">{d.speedNote} {d.noAudio}</p>
        <progress value={pb.idx + 1} max={sel.length} aria-label={d.now} style={{ width: "100%" }} />
        <p className="big" aria-hidden="true">{mname(cur.month)} {cur.year} · {nf(cur.anomaly)} °C · {freq?.toFixed(1)} {d.hz}</p>
        <div className="sr" role="status" aria-live="polite">{live}</div>
        <div className="grid2"><div><SpiralChart rows={sel} idx={pb.idx} label={d.spiralLabel} desc={d.spiralDesc} ring="0 °C" /><p className="mut">{d.derived}</p></div>
          {!prefs.simple && <div><LineChart rows={sel} idx={pb.idx} desc={desc} /><p className="mut">{desc}</p></div>}</div>
        <h3>{d.seeSound}</h3>
        <canvas ref={pb.cv} width={1000} height={150} role="img" aria-label={d.waveLabel} />
        {prefs.visual && freq !== null && <div aria-hidden="true"><div className="bar"><div style={{ width: `${pos * 100}%` }} /></div><p className="big">{freq.toFixed(0)} {d.hz} · {pos < 0.34 ? d.pitchLow : pos < 0.67 ? d.pitchMid : d.pitchHigh}</p></div>}
        {!prefs.simple && <Det summary={d.soundSettings}><div className="row">
          <label>{d.year}<select value={cur.year} onChange={(e) => goTo(+e.target.value, cur.month)}>{years.map((y) => <option key={y}>{y}</option>)}</select></label>
          <label>{d.month}<select value={cur.month} onChange={(e) => goTo(cur.year, +e.target.value)}>{Array.from({ length: 12 }, (_, i) => <option key={i} value={i + 1}>{mname(i + 1)}</option>)}</select></label>
          <button onClick={() => pb.hearOne(pb.idx)}>{d.hearMonth}</button></div></Det>}
      </section>}

      {prefs.captions && data && cur && <section className="card" aria-labelledby="c5"><h2 id="c5">{d.tCaptions}</h2>
        <p className="cap" aria-hidden="true">{evt(cur)}</p><Det summary={d.transcript}>{tr.length ? <ol className="tr">{tr.map((t, i) => <li key={i}>{t}</li>)}</ol> : <p>{d.noTranscript}</p>}</Det></section>}

      <section className="card" aria-labelledby="c6"><h2 id="c6">{d.tMap}</h2><p>{d.howText}</p></section>
      <section className="card" aria-labelledby="c7"><h2 id="c7">{d.tRefs}</h2><p>{d.limitsText}</p>
        <ul><li><a href={`https://svs.gsfc.nasa.gov/${svsId}/`} target="_blank" rel="noopener">NASA SVS {svsId}</a> (NASA Scientific Visualization Studio)</li>
          <li><a href="https://data.giss.nasa.gov/gistemp/" target="_blank" rel="noopener">NASA GISS GISTEMP v4</a></li></ul>
        {data && <p className="mut">{d.stored}: {new Date(data.fetchedAt).toLocaleString(lang)}. {d.staleNote}</p>}</section>
    </article>
  );
}
