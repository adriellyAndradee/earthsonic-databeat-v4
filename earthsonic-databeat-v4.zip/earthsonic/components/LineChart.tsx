import type { Row } from "../lib/gistemp";
export default function LineChart({ rows, idx, desc }: { rows: Row[]; idx?: number; desc: string }) {
  if (!rows.length) return null;
  const W = 1000, H = 260, P = 34, mn = Math.min(...rows.map((r) => r.anomaly)), mx = Math.max(...rows.map((r) => r.anomaly));
  const X = (i: number) => P + (i / Math.max(1, rows.length - 1)) * (W - 2 * P), Y = (a: number) => H - P - ((a - mn) / (mx - mn || 1)) * (H - 2 * P);
  const k = idx === undefined ? -1 : Math.min(idx, rows.length - 1);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={desc}>
      <polyline fill="none" stroke="#35e0ff" strokeWidth="2" points={rows.map((r, i) => `${X(i).toFixed(1)},${Y(r.anomaly).toFixed(1)}`).join(" ")} />
      {mn < 0 && mx > 0 && <line x1={P} x2={W - P} y1={Y(0)} y2={Y(0)} stroke="#a9bfdc" strokeDasharray="6 6" />}
      {k >= 0 && <><line x1={X(k)} x2={X(k)} y1={10} y2={H - P} stroke="#ffa23a" strokeWidth="3" /><circle cx={X(k)} cy={Y(rows[k].anomaly)} r="7" fill="#ffa23a" /></>}
      <text x={P} y={H - 8} fill="#a9bfdc" fontSize="14">{rows[0].year}</text><text x={W - P - 40} y={H - 8} fill="#a9bfdc" fontSize="14">{rows[rows.length - 1].year}</text>
    </svg>
  );
}
