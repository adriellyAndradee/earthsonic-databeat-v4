import type { Row } from "../lib/gistemp";
export default function SpiralChart({ rows, idx, label, desc, ring }: { rows: Row[]; idx: number; label: string; desc: string; ring: string }) {
  if (!rows.length) return null;
  const S = 520, C = S / 2, r0 = 50, R = 200, mn = Math.min(...rows.map((r) => r.anomaly)), mx = Math.max(...rows.map((r) => r.anomaly));
  const rad = (a: number) => r0 + ((a - mn) / (mx - mn || 1)) * R;
  const pt = (r: Row) => { const th = ((r.month - 1) / 12) * 2 * Math.PI - Math.PI / 2, rr = rad(r.anomaly); return [C + rr * Math.cos(th), C + rr * Math.sin(th)]; };
  const k = Math.min(idx, rows.length - 1), all = rows.map((r) => pt(r).map((v) => v.toFixed(1)).join(",")), cur = pt(rows[k]);
  return (
    <svg viewBox={`0 0 ${S} ${S}`} role="img" aria-label={`${label}. ${desc}`}>
      {mn < 0 && mx > 0 && <circle cx={C} cy={C} r={rad(0)} fill="none" stroke="#a9bfdc" strokeDasharray="6 6" />}
      <text x={C + 6} y={C - rad(0) - 4} fill="#a9bfdc" fontSize="13">{ring}</text>
      <polyline points={all.slice(0, k + 1).join(" ")} fill="none" stroke="#35e0ff" strokeWidth="1.5" />
      <polyline points={all.slice(k).join(" ")} fill="none" stroke="#35e0ff" strokeOpacity=".25" strokeWidth="1" strokeDasharray="2 3" />
      <circle cx={cur[0]} cy={cur[1]} r="9" fill="#ffa23a" stroke="#fff" strokeWidth="2" />
    </svg>
  );
}
