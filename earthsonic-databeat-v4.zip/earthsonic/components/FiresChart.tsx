export default function FiresChart({ days, idx, desc }: { days: { date: string; count: number; frpMean: number }[]; idx?: number; desc: string }) {
  if (!days.length) return null;
  const W = 1000, H = 260, P = 34, mc = Math.max(...days.map((x) => x.count)) || 1, mf = Math.max(...days.map((x) => x.frpMean)) || 1, bw = (W - 2 * P) / days.length;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={desc}>
      {days.map((x, i) => <rect key={x.date} x={P + i * bw} width={Math.max(1, bw - 2)} y={H - P - (H - 2 * P) * x.count / mc} height={(H - 2 * P) * x.count / mc} fill={i === idx ? "#fff" : "#35e0ff"} />)}
      <polyline fill="none" stroke="#ffa23a" strokeWidth="3" strokeDasharray="8 5" points={days.map((x, i) => `${P + i * bw + bw / 2},${H - P - (H - 2 * P) * x.frpMean / mf}`).join(" ")} />
      <text x={P} y={16} fill="#a9bfdc" fontSize="14">max {mc}</text><text x={P} y={H - 8} fill="#a9bfdc" fontSize="14">{days[0].date}</text><text x={W - P - 90} y={H - 8} fill="#a9bfdc" fontSize="14">{days[days.length - 1].date}</text>
    </svg>
  );
}
