"use client";
import Link from "next/link";
import { useApp } from "./AppProvider";
import Badge from "./Badge";
import { CATALOG, type Exp } from "../lib/eic/catalog";
import { CATS } from "../lib/eic/categories";

const ICON: Record<string, string> = { climate: "🌡️", fires: "🔥", oceans: "🌊" };
const HAS_PAGE = ["climate", "fires"];

function ExpTile({ e }: { e: Exp }) {
  const { d } = useApp(); const inner = (<><div className="viz" aria-hidden="true">{ICON[e.slug]}</div><h3>{d.expTitles[e.key]}</h3><p>{d.expDesc[e.key]}</p><Badge st={e.status} /></>);
  return <li>{HAS_PAGE.includes(e.slug) ? <Link className="card tile" href={`/experiences/${e.slug}`}>{inner}<p><strong>{d.openExp} →</strong></p></Link> : <div className="card tile dim">{inner}</div>}</li>;
}

export function Home() {
  const { d } = useApp();
  return (<>
    <section className="hero"><div><p className="brand">EARTHSONIC</p><h1>{d.slogan}</h1><p className="lead">{d.homeDesc}</p>
      <div className="row"><Link className="btn pri big" href="/discover">{d.exploreEarth}</Link><Link className="btn big" href="/about">{d.howItWorks}</Link></div></div>
      <div className="earth" role="img" aria-label={d.decorative} /></section>
    <section className="card" aria-labelledby="son"><h2 id="son">{d.sonifTitle}</h2><p>{d.sonifText}</p></section>
    <section aria-labelledby="stp"><h2 id="stp">{d.howTitle}</h2>
      <ol className="steps"><li><strong>{d.step1T}</strong><p>{d.step1}</p></li><li><strong>{d.step2T}</strong><p>{d.step2}</p></li><li><strong>{d.step3T}</strong><p>{d.step3}</p></li></ol></section>
    <section aria-labelledby="prv"><h2 id="prv">{d.previewTitle}</h2><ul className="tiles">{CATALOG.map((e) => <ExpTile key={e.slug} e={e} />)}</ul>
      <p><Link className="btn" href="/experiences">{d.navExp} →</Link></p></section>
  </>);
}

export function Discover() {
  const { d } = useApp();
  return (<>
    <h1>{d.discoverTitle}</h1><p className="lead">{d.discSub}</p>
    <ul className="tiles">{CATS.map((c) => (
      <li key={c.k} className="card tile"><div className="viz" aria-hidden="true">{c.icon}</div><h3>{d.cats[c.k]}</h3><p>{d.catsDesc[c.k]}</p><Badge st={c.st} />
        <div style={{ marginTop: ".6rem" }}>
          {c.href && <Link className={`btn${c.st === "available" ? " pri" : ""}`} href={c.href}>{d.openExp}</Link>}
          {c.st !== "available" && <details><summary>{d.learnMore}</summary><p>{c.st === "validation" ? d.stValidMsg : d.stSoonMsg}</p>
            {c.ref && <p>{d.svsRef}: <a href={`https://svs.gsfc.nasa.gov/${c.ref}/`} target="_blank" rel="noopener">SVS {c.ref}</a></p>}</details>}
        </div></li>))}</ul>
    <p className="mut">{d.decorative}.</p>
  </>);
}

export function Experiences() {
  const { d } = useApp();
  return (<><h1>{d.expTitle}</h1><p className="lead">{d.expSub}</p><ul className="tiles">{CATALOG.map((e) => <ExpTile key={e.slug} e={e} />)}</ul></>);
}

export function About() {
  const { d } = useApp();
  return (<>
    <h1>{d.aboutTitle}</h1><p className="lead">{d.aboutText}</p>
    <section aria-labelledby="hw"><h2 id="hw">{d.howTitle}</h2>
      <ol className="steps"><li><strong>{d.step1T}</strong><p>{d.step1}</p></li><li><strong>{d.step2T}</strong><p>{d.step2}</p></li><li><strong>{d.step3T}</strong><p>{d.step3}</p></li></ol>
      <p>{d.sonifText}</p><p>{d.aboutMethod}</p></section>
    <section className="card" aria-labelledby="lm"><h2 id="lm">{d.tRefs}</h2><p>{d.aboutLimits}</p><p className="warn">{d.aboutDisclaimer}</p></section>
    <section aria-labelledby="sc"><h2 id="sc">{d.sources}</h2>
      <ul className="tiles">{CATALOG.map((e) => (
        <li key={e.slug} className="card tile"><h3>{d.expTitles[e.key]}</h3><Badge st={e.status} />
          <p><strong>{d.source}:</strong> <a href={e.url} target="_blank" rel="noopener">NASA SVS {e.svsId}</a> · <a href={e.dataUrl} target="_blank" rel="noopener">{e.dataSource}</a><br />
            <strong>{d.variable}:</strong> {e.variable}<br /><strong>{d.unit}:</strong> {e.unit}<br /><strong>{d.period}:</strong> {e.period}<br /><strong>{d.eic}:</strong> {d.unverified}</p></li>))}</ul>
      <p>NASA Scientific Visualization Studio · NASA GISS · NASA FIRMS. {d.aboutDisclaimer}</p></section>
  </>);
}
