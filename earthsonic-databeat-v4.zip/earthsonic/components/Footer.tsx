"use client";
import { useApp } from "./AppProvider";
export default function Footer() { const { d } = useApp(); return <footer className="foot"><p>{d.madeBy} · {d.aboutDisclaimer}</p></footer>; }
