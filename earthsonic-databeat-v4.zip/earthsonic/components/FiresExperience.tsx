"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { rolling, type Day } from "../lib/firms";
import { useApp } from "./AppProvider";
import { usePlayback } from "./usePlayback";
import { FiresControls, useFires } from "./FiresControls";
import FiresChart from "./FiresChart";
import Det from "./Det";

type Item = Day & { f: number; pulses: number };
export default function FiresExperience() {
  const { lang, d, prefs } = useApp(); const f = useFires(); const [roll, setRoll] = useState(true), [live, setLive] = useState(""), [tr, setTr] = useState<string[]>([]);
  const nf = (v: number, n = 1) => v.toLocaleString(lang, { maximumFractionDigits: n });
  const items = useMemo<Item[]>(() => {
    if (!f.data || !f.data.days.length) return [];
    const days = roll ? rolling(f.data.days, 5) : f.data.days, fr = days.map((x) => x.frpMean).filter((v) => v > 0);
    if (!fr.length) return []; const lo = Math.log(Math.min(...fr)), hi = Math.log(Math.max(...fr)), mc = Math.max(...days.map((x) => x.count));
    return days.map((x) => ({ ...x, f: 220 * Math.pow(2, 2 * ((Math.log(Math.max(x.frpMean, 1e-6)) - lo) / (hi - lo || 1))), pulses: 1 + Math.round((5 * x.count) / mc) }));
  }, [f.data, roll]);
  const evt = (x: Item) => d.fEvent(x.date, x.count, nf(x.frpMean), nf(x.f), x.pulses);
  const pb = usePlayback<Item>(items, {
    note: (x, sp, e) => { const step = 0.15 / sp; for (let i = 0; i < x.pulses; i++) e.note(x.f, 0.05 / sp, (i * step) / x.pulses); },
    step: (x) => { setTr((t) => [...t.slice(-99), evt(x)]); if (prefs.verbose) setLive(evt(x)); }, end: () => setLive(d.ended),
  });
  const cur = items[Math.min(pb.idx, items.length - 1)];
  const peak = items.reduce((a, x) => (x.count > a.count ? x : a), items[0] ?? { date: "", count: 0 } as Item);
  const desc = items.length ? d.fDesc(items[0].date, items[items.length - 1].date, items.reduce((s, x) => s + x.count, 0), peak.date, peak.count) : "";
  return (
    <article>
      <Link className="back" href="/experiences">← {d.back}</Link>
      <h1>{d.expTitles.wildfires}</h1><p className="lead">{d.fIntro}</p><p className="warn">{d.fValid}</p>
      <section className="card" aria-labelledby="f1"><h2 id="f1">{d.s2}</h2><FiresControls f={f} />
        <label className="row" style={{ marginTop: ".6rem" }}><input type="checkbox" checked={roll} onChange={(e) => setRoll(e.target.checked)} style={{ width: 28, height: 28 }} /> {d.fRoll}</label>
        {f.err?.missingKey && <p className="warn" role="alert">{d.fNeedKey}</p>}
        {f.err && !f.err.missingKey && <p className="warn" role="alert">{d.failData}{f.err.detail && process.env.NODE_ENV !== "production" ? ` (${f.err.detail})` : ""}</p>}
        {f.data && <p className="mut">{d.fCollected}: {new Date(f.data.collectedAt).toLocaleString(lang)} · {f.data.products.join(", ")} · {f.data.start} → {f.data.end} · {d.fCount}: {f.data.detections}{f.data.versions.length ? ` · v${f.data.versions.join(", ")}` : ""}</p>}
        {f.data && !items.length && <p>{d.fNoData}</p>}</section>
      {items.length > 0 && cur && <>
        <section className="card" aria-labelledby="f2"><h2 id="f2">{d.s3}</h2>
          <div className="row">
            {pb.playing ? <button className="pri" onClick={pb.pause}>⏸ {d.pause}</button> : <button className="pri" onClick={() => pb.play()}>▶ {pb.paused() ? d.resume : d.play}</button>}
            <button onClick={() => { pb.stop(); setTr([]); }}>⏹ {d.stop}</button><button onClick={() => { setTr([]); pb.restart(); }}>⟲ {d.restart}</button>
            <label>{d.sonSpeed}<select value={pb.speed} onChange={(e) => pb.setSpeed(+e.target.value)}>{[0.5, 0.75, 1, 1.5, 2].map((s) => <option key={s} value={s}>{s}x</option>)}</select></label>
            <label>{d.volume}<input type="range" min={0} max={100} value={pb.vol} onChange={(e) => pb.setVol(+e.target.value)} /></label></div>
          <p className="mut">{d.noAudio}</p><progress value={pb.idx + 1} max={items.length} aria-label={d.now} style={{ width: "100%" }} />
          <p className="big" aria-hidden="true">{cur.date} · {nf(cur.count, 0)} {d.fCount.toLowerCase()} · {nf(cur.frpMean)} MW · {nf(cur.f)} {d.hz}</p>
          <div className="sr" role="status" aria-live="polite">{live}</div>
          <FiresChart days={items} idx={pb.idx} desc={desc} /><p className="mut">{desc} {d.fCount}: {d.fFrp}.</p>
          <h3>{d.seeSound}</h3><canvas ref={pb.cv} width={1000} height={150} role="img" aria-label={d.waveLabel} />
          {prefs.visual && <div aria-hidden="true"><div className="bar"><div style={{ width: `${Math.min(100, (cur.pulses / 6) * 100)}%` }} /></div><p className="big">{cur.pulses} · {nf(cur.f)} {d.hz}</p></div>}
          <Det summary={d.showTable}><div className="scroll"><table><thead><tr><th scope="col">{d.fEnd}</th><th scope="col">{d.fCount}</th><th scope="col">{d.fFrp}</th><th scope="col">{d.fFrpSum}</th></tr></thead>
            <tbody>{items.map((x) => <tr key={x.date}><td>{x.date}</td><td>{x.count}</td><td>{nf(x.frpMean)}</td><td>{nf(x.frpSum)}</td></tr>)}</tbody></table></div></Det></section>
        {prefs.captions && <section className="card" aria-labelledby="f3"><h2 id="f3">{d.tCaptions}</h2><p className="cap" aria-hidden="true">{evt(cur)}</p><Det summary={d.transcript}>{tr.length ? <ol className="tr">{tr.map((t, i) => <li key={i}>{t}</li>)}</ol> : <p>{d.noTranscript}</p>}</Det></section>}
      </>}
      <section className="card" aria-labelledby="f4"><h2 id="f4">{d.tMap}</h2><p>{d.fMapText}</p><p>{d.fBox}</p></section>
      <section className="card" aria-labelledby="f5"><h2 id="f5">{d.tRefs}</h2>
        <ul><li><a href="https://svs.gsfc.nasa.gov/5113/" target="_blank" rel="noopener">NASA SVS 5113</a></li><li><a href="https://firms.modaps.eosdis.nasa.gov/" target="_blank" rel="noopener">NASA FIRMS</a></li></ul></section>
    </article>
  );
}
